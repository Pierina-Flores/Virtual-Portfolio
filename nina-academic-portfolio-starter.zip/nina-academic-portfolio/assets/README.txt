Add your headshot, résumé PDF, research poster, and project images here. See the main README for setup instructions.
