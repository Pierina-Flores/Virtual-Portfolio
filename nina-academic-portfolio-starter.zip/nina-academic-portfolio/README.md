# Nina's Academic Portfolio

A responsive personal + academic portfolio built with plain HTML, CSS, and JavaScript. It is designed for GitHub Pages, so no build tools or paid hosting are required.

## Files
- `index.html` — page content and sections
- `styles.css` — responsive layout and visual design
- `script.js` — mobile navigation and small interactions
- `assets/` — add your headshot, research poster, résumé, and other images here

## Before publishing
Search the project for these placeholders and replace them:
- `Nina` / `[Last Name]` — add your preferred full professional name
- `YOUR.EMAIL@example.com` — add a professional email address
- `YOUR-GITHUB-USERNAME` — add your GitHub username
- `data-placeholder="resume"` — replace with your résumé PDF link
- `data-placeholder="research-poster"` — replace with your poster PDF or project page
- `data-placeholder="linkedin"` — add your LinkedIn URL

Also review every description to make sure it accurately reflects your role and contributions.

## Add your headshot
1. Add a professional photo to `assets/` and name it `headshot.jpg`.
2. To display it, add an image element to the hero or About section in `index.html`, for example:
   `<img class="headshot" src="assets/headshot.jpg" alt="Portrait of Nina">`
3. Add styling in `styles.css` for `.headshot`, such as `width: 160px; aspect-ratio: 1; object-fit: cover; border-radius: 50%;`.

## Publish with GitHub Pages
1. Create a new public repository named `academic-portfolio` (or another name you prefer).
2. Upload the contents of this folder to the repository's root. Do not upload only the ZIP file.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. After GitHub finishes publishing, your site will be available at:
   `https://YOUR-GITHUB-USERNAME.github.io/academic-portfolio/`

If you name the repository exactly `YOUR-GITHUB-USERNAME.github.io`, the site can instead use the shorter root URL:
`https://YOUR-GITHUB-USERNAME.github.io/`

## Good portfolio practice
- Only publish information and contact details you are comfortable making public.
- Link to selected work; don't upload private research data or unpublished material without permission.
- Use captions and alt text for images.
- Keep the portfolio updated as your projects and experience develop.
